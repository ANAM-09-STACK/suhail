window.addEventListener("load", () => {
  setTimeout(() => document.getElementById("loading").classList.add("hide"), 700);
});

document.getElementById("openBtn").addEventListener("click", () => {
  document.getElementById("details").classList.add("show");
  document.getElementById("details").scrollIntoView({ behavior: "smooth" });
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("show");
  });
}, { threshold: 0.15 });

observer.observe(document.getElementById("details"));

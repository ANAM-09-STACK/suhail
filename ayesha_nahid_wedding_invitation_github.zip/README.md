# Ayesha & Nahid — Wedding Invitation

A mobile-friendly animated wedding invitation made with plain HTML, CSS and JavaScript.

## Events
- Nikah — 25 October
- Valima — 26 October

## How to publish on GitHub Pages

1. Create a new GitHub repository, for example `ayesha-nahid-wedding`.
2. Upload these files:
   - `index.html`
   - `style.css`
   - `script.js`
   - `invitation.png`
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish.
7. Your invitation will have a shareable GitHub Pages address.

## Important
The venue is intentionally left as a placeholder because no actual venue name/address was supplied.
